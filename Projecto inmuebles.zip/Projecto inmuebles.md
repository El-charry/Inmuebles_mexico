```python
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

```

**Ejemplo de dataframe**


```python

#Ejemplo de dataframe
data = {'Nombre': ['Ana', 'Juan', 'María', 'Pedro'],
        'Edad': [20, 22, 19, 21],
        'Carrera': ['Ingeniería', 'Contabilidad', 'Medicina', 'Informática'],
        'Calificación': [8.5, 9.2, 7.8, 9.5]}
df = pd.DataFrame(data)

print(df)
```

      Nombre  Edad       Carrera  Calificación
    0    Ana    20    Ingeniería           8.5
    1   Juan    22  Contabilidad           9.2
    2  María    19      Medicina           7.8
    3  Pedro    21   Informática           9.5
    

**Creación de visualizaciones con los datos**



```python
# Gráfico de barras

sns.barplot(x='Carrera', y='Calificación', data=df)
plt.title('Calificación promedio por carrera')
plt.xlabel('Carrera')
plt.ylabel('Calificación')
plt.show()
```


    
![png](output_4_0.png)
    


**Cargar información en base a un conjunto de datos (Excel)**



```python
df = pd.read_excel('inmuebles.xlsx')
```


```python
df.head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Referencia</th>
      <th>FechaAlta</th>
      <th>Tipo</th>
      <th>Operación</th>
      <th>Ciudad</th>
      <th>Superficie</th>
      <th>Precio Venta</th>
      <th>Fecha Venta</th>
      <th>Vendedor</th>
      <th>Estatus</th>
      <th>Días para Vender</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>2016-01-18</td>
      <td>Estacionamiento</td>
      <td>Alquiler</td>
      <td>Cancún</td>
      <td>215</td>
      <td>1154980</td>
      <td>2017-01-14</td>
      <td>Joaquín</td>
      <td>Vendida</td>
      <td>362</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>2016-01-20</td>
      <td>Oficina</td>
      <td>Alquiler</td>
      <td>Tijuana</td>
      <td>287</td>
      <td>2851058</td>
      <td>2017-01-02</td>
      <td>Joaquín</td>
      <td>Vendida</td>
      <td>348</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>2016-01-20</td>
      <td>Local</td>
      <td>Venta</td>
      <td>Monterrey</td>
      <td>40</td>
      <td>321680</td>
      <td>2017-01-11</td>
      <td>Jesús</td>
      <td>Vendida</td>
      <td>357</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>2016-01-24</td>
      <td>Industrial</td>
      <td>Venta</td>
      <td>Cancún</td>
      <td>178</td>
      <td>1142938</td>
      <td>2017-01-23</td>
      <td>Joaquín</td>
      <td>Vendida</td>
      <td>365</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>2016-02-03</td>
      <td>Departamento</td>
      <td>Venta</td>
      <td>Monterrey</td>
      <td>275</td>
      <td>2141700</td>
      <td>2017-01-08</td>
      <td>Jesús</td>
      <td>Vendida</td>
      <td>340</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Cantidad de filas y columnas
df.shape
```




    (2651, 11)




```python
#Información de los datos
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 2651 entries, 0 to 2650
    Data columns (total 11 columns):
     #   Column            Non-Null Count  Dtype         
    ---  ------            --------------  -----         
     0   Referencia        2651 non-null   int64         
     1   FechaAlta         2651 non-null   datetime64[ns]
     2   Tipo              2651 non-null   object        
     3   Operación         2651 non-null   object        
     4   Ciudad            2651 non-null   object        
     5   Superficie        2651 non-null   int64         
     6   Precio Venta      2651 non-null   int64         
     7   Fecha Venta       2651 non-null   datetime64[ns]
     8   Vendedor          2387 non-null   object        
     9   Estatus           2651 non-null   object        
     10  Días para Vender  2651 non-null   int64         
    dtypes: datetime64[ns](2), int64(4), object(5)
    memory usage: 227.9+ KB
    


```python
# Lista de campos de la base de datos
for col in df.columns:
    print(col)
```

    Referencia
    FechaAlta
    Tipo
    Operación
    Ciudad
    Superficie
    Precio Venta
    Fecha Venta
    Vendedor
    Estatus
    Días para Vender
    


```python
# Características estadísticas de las columnas seleccionadas
df[['Superficie','Precio Venta','Días para Vender']].describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Superficie</th>
      <th>Precio Venta</th>
      <th>Días para Vender</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>2651.000000</td>
      <td>2.651000e+03</td>
      <td>2651.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>171.201811</td>
      <td>1.211656e+06</td>
      <td>365.289702</td>
    </tr>
    <tr>
      <th>std</th>
      <td>74.937985</td>
      <td>6.261026e+05</td>
      <td>200.002488</td>
    </tr>
    <tr>
      <th>min</th>
      <td>40.000000</td>
      <td>1.639200e+05</td>
      <td>90.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>106.000000</td>
      <td>6.980235e+05</td>
      <td>190.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>172.000000</td>
      <td>1.140876e+06</td>
      <td>323.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>237.000000</td>
      <td>1.642624e+06</td>
      <td>542.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>300.000000</td>
      <td>2.977318e+06</td>
      <td>730.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Este es un estilo de consulta con el numero que ponga. Lo va a buscar a la base de datos y selecciona toda la fila
df.iloc[874]
```




    Referencia                          875
    FechaAlta           2017-03-20 00:00:00
    Tipo                            Oficina
    Operación                      Alquiler
    Ciudad                          Tijuana
    Superficie                          274
    Precio Venta                    1152718
    Fecha Venta         2017-07-31 00:00:00
    Vendedor                          Pedro
    Estatus                         Vendida
    Días para Vender                    133
    Name: 874, dtype: object




```python
#Busca desde el 18 hasta el 20
df.iloc[18:20]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Referencia</th>
      <th>FechaAlta</th>
      <th>Tipo</th>
      <th>Operación</th>
      <th>Ciudad</th>
      <th>Superficie</th>
      <th>Precio Venta</th>
      <th>Fecha Venta</th>
      <th>Vendedor</th>
      <th>Estatus</th>
      <th>Días para Vender</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>18</th>
      <td>19</td>
      <td>2016-03-02</td>
      <td>Oficina</td>
      <td>Venta</td>
      <td>Cancún</td>
      <td>172</td>
      <td>1063648</td>
      <td>2017-02-13</td>
      <td>María</td>
      <td>Vendida</td>
      <td>348</td>
    </tr>
    <tr>
      <th>19</th>
      <td>20</td>
      <td>2016-03-06</td>
      <td>Estacionamiento</td>
      <td>Venta</td>
      <td>Monterrey</td>
      <td>169</td>
      <td>1370759</td>
      <td>2017-01-14</td>
      <td>Luisa</td>
      <td>Vendida</td>
      <td>314</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Busca en la columna Vendedor, que este en la fila 500
df['Vendedor'][2000]
```




    'Joaquín'




```python
#Muestra aleatoria 
df.sample(3)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Referencia</th>
      <th>FechaAlta</th>
      <th>Tipo</th>
      <th>Operación</th>
      <th>Ciudad</th>
      <th>Superficie</th>
      <th>Precio Venta</th>
      <th>Fecha Venta</th>
      <th>Vendedor</th>
      <th>Estatus</th>
      <th>Días para Vender</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2507</th>
      <td>2508</td>
      <td>2018-11-08</td>
      <td>Local</td>
      <td>Alquiler</td>
      <td>Tijuana</td>
      <td>174</td>
      <td>799356</td>
      <td>2019-02-06</td>
      <td>NaN</td>
      <td>En Proceso</td>
      <td>90</td>
    </tr>
    <tr>
      <th>1496</th>
      <td>1497</td>
      <td>2016-11-03</td>
      <td>Terreno</td>
      <td>Venta</td>
      <td>Ciudad de México</td>
      <td>70</td>
      <td>540890</td>
      <td>2018-06-12</td>
      <td>Jesús</td>
      <td>Vendida</td>
      <td>586</td>
    </tr>
    <tr>
      <th>2064</th>
      <td>2065</td>
      <td>2018-05-23</td>
      <td>Casa</td>
      <td>Alquiler</td>
      <td>Cancún</td>
      <td>202</td>
      <td>1112010</td>
      <td>2019-01-29</td>
      <td>Pedro</td>
      <td>Vendida</td>
      <td>251</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Promedio
promedio = df['Precio Venta'].mean()
print("Promedio:", promedio)

# Mediana
mediana = df['Precio Venta'].median()
print("Mediana:", mediana)

# Moda
moda = df['Precio Venta'].mode()
print("Moda:", moda)
```

    Promedio: 1211656.4907582044
    Mediana: 1140876.0
    Moda: 0      358670
    1      416430
    2      419256
    3      446940
    4      544896
    5      574200
    6      797215
    7      913248
    8      917378
    9     1191044
    10    1199394
    11    1342278
    12    2682225
    Name: Precio Venta, dtype: int64
    


```python
#Precio promedio de venta por ciudad: Examina los precios de venta promedio para cada ciudad.
df.groupby('Ciudad')['Precio Venta'].mean().round()
```




    Ciudad
    Cancún              1180772.0
    Ciudad de México    1213952.0
    Monterrey           1218331.0
    Tijuana             1233933.0
    Name: Precio Venta, dtype: float64




```python
valor_minimo = df['Precio Venta'].min()
valor_maximo = df['Precio Venta'].max()
```

**Grafico de lineas de las ventas durante todos los meses**


```python
#Grafico de lineas para mostrar las vendas en cada mes

import matplotlib.pyplot as plt

# Crear el gráfico de línea
ax = df.groupby(df['Fecha Venta'].dt.to_period('M')).size().plot(kind='line')

# Obtener los datos de X y Y del gráfico
x_values = ax.get_lines()[0].get_xdata()
y_values = ax.get_lines()[0].get_ydata()

# Agregar etiquetas de datos
for x, y in zip(x_values, y_values):
    plt.annotate(f'{int(y)}', xy=(x, y), xytext=(0, 5), textcoords='offset points', ha='center')
#Color y grosor de la linea
ax = df.groupby(df['Fecha Venta'].dt.to_period('M')).size().plot(kind='line', color='red',linewidth=5)


# Personalizar el gráfico
plt.title('Ventas por Meses')
plt.xlabel('Meses')
plt.ylabel('Número de Ventas')
plt.grid(True)
plt.show()
```


    
![png](output_20_0.png)
    


**Diagrama circular del estatus del inmueble (Vendida vs En proceso)**


```python
df['Estatus'].value_counts().plot(kind='pie', 
                                  title='Estatus', 
                                  autopct='%1.1f%%',  # Muestra el porcentaje con 1 decimal
                                  startangle=90,  # Para que el gráfico comience desde arriba
                                  figsize=(5, 5),  # Tamaño del gráfico
                                  wedgeprops={'edgecolor': 'black'})  # Bordes de los sectores

```




    <Axes: title={'center': 'Estatus'}, ylabel='count'>




    
![png](output_22_1.png)
    


**Tipo y cantidad de cada inmueble**


```python
import matplotlib.pyplot as plt
import pandas as pd

# Contar la frecuencia de cada tipo de inmueble
conteo_tipos = df['Tipo'].value_counts()

# Crear el gráfico de barras
conteo_tipos.plot(kind='bar', title='Tipos de inmuebles')

# Agregar etiquetas a las barras
for i in range(len(conteo_tipos)):
    plt.text(i, conteo_tipos.iloc[i], str(conteo_tipos.iloc[i]), ha='center', va='bottom')

# Etiquetas de los ejes
plt.xlabel('Inmuebles')
plt.ylabel('Cantidad de inmuebles')
plt.xticks(rotation=45) #inclinacion de los nombres
# Mostrar el gráfico
plt.show()
```


    
![png](output_24_0.png)
    


**Cantidad de ventas vs alquiler**


```python
#Alquiler vs Ventas
df['Operación'].value_counts().plot(kind='pie', 
                                    title='Distribución de las operaciones', 
                                    autopct=lambda p: '{:.0f}'.format(p * sum(df['Operación'].value_counts()) / 100),  # Muestra el valor absoluto
                                    startangle=90, 
                                    figsize=(6, 6), 
                                    wedgeprops={'edgecolor': 'black'})
```




    <Axes: title={'center': 'Distribución de las operaciones'}, ylabel='count'>




    
![png](output_26_1.png)
    

Este grafico de pie o circular nos muestra un breve resumen de las ventas vs los alquileres. Donde las ventas superan lijeramente 
los que son de alquiler. 

```python

```

**Grafico de Barras horizontales de vendedores por la cantidad de ventas que realizaron**


```python
import matplotlib.pyplot as plt


# Contar la frecuencia de cada tipo de inmueble
conteo_tipos = df['Vendedor'].value_counts()

# Crear el gráfico de barras horizontales
conteo_tipos.plot(kind='barh', title='Vendedores')

# Agregar etiquetas a las barras (ahora en el eje horizontal)
for i, v in enumerate(conteo_tipos):
    plt.text(v, i, str(v), va='center')

# Etiquetas de los ejes
plt.xlabel('Cantidad de ventas')
plt.ylabel('Nombre del vendedor')



# Mostrar el gráfico
plt.show()
```


    
![png](output_30_0.png)
    

Todos los vendedores tienen un desempeño bastante cercano, donde el primero hasta el último solo hay una 
diferencia de 45 unidades, esta brecha puede ser por diferentes factores como lo son la experiencia, la red de contactos,
la atención al cliente o las capacidades de negociación. Para mejorar estos aspectos se puede hacer:
* Bridar capacitaciones en tecnicas de ventas, manejo de objeciones y cierre de ventas.
* Juntar los mejores vendedores con aquellos que estan por debajo, soluciones personalizadas e insentivos.
Podemos destacar a Luisa y a Carmen como vendedoras estrellas, ya que sus ventas superan el promedio en comparación con sus compañeros.

```python
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt

# Seleccionar las características relevantes
X = df[['Superficie', 'Precio Venta']]

# Escalar los datos
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Numero de clusters
num_clusters = 3

# Crear y ajustar el modelo K-means
kmeans = KMeans(n_clusters=num_clusters, random_state=42)
kmeans.fit(X_scaled)

# Agregar los labels de los clusters al DataFrame original
df['Cluster'] = kmeans.labels_

# Visualizar los clusters
plt.scatter(df['Superficie'], df['Precio Venta'], c=df['Cluster'], cmap='rainbow')
plt.xlabel('Superficie')
plt.ylabel('Precio Venta')
plt.title('Clustering de Inmuebles con K-means')
plt.show()
```


    
![png](output_32_0.png)
    

El grafico de K-means podemos resaltar tres grupos, con caracteristicas distintas
en cuanto tamaño y precio. Podemos councluirque podemos tener tres nichos como por ejemplo viviendas
de lujo, viviendas con tamaño medio y por ultimo casas pequeñas.
Tenemos una relacion positiva debido a que ambas variables "Superficie" y "Precio Venta" aumentan, no es un
patron exacto pero hay una tendencia

```python
import matplotlib.pyplot as plt
import seaborn as sns

# Descripción de los datos
print(df['Precio Venta'].describe())

# Configuración de la figura
plt.figure(figsize=(6, 5))

# Trazar el histograma y la curva de densidad
sns.histplot(df['Precio Venta'], color='blue', bins=100, kde=True, stat="density", alpha=0.4)

# Mostrar el gráfico
plt.title('Histograma de Precio Venta')
plt.xlabel('Precio Venta')
plt.ylabel('Densidad')
plt.show()
```

    count    2.651000e+03
    mean     1.211656e+06
    std      6.261026e+05
    min      1.639200e+05
    25%      6.980235e+05
    50%      1.140876e+06
    75%      1.642624e+06
    max      2.977318e+06
    Name: Precio Venta, dtype: float64
    


    
![png](output_34_1.png)
    



```python
propiedades_lentas = df.sort_values(by='Días para Vender', ascending=False)
print(propiedades_lentas.head(15).to_string())
```

          Referencia  FechaAlta             Tipo Operación            Ciudad  Superficie  Precio Venta Fecha Venta Vendedor  Estatus  Días para Vender  Cluster
    1427        1428 2016-10-06          Terreno  Alquiler  Ciudad de México         132        882420  2018-10-06   Carmen  Vendida               730        1
    1484        1485 2016-10-28          Terreno     Venta           Tijuana         249       1878954  2018-10-28    Luisa  Vendida               730        0
    1482        1483 2016-10-28     Departamento  Alquiler         Monterrey         164       1421060  2018-10-28    Luisa  Vendida               730        2
    898          899 2016-03-30       Industrial  Alquiler         Monterrey         167       1191044  2018-03-30  Joaquín  Vendida               730        2
    929          930 2016-04-09            Local     Venta         Monterrey         290       1702590  2018-04-09    Pedro  Vendida               730        0
    1046        1047 2016-05-21             Casa  Alquiler           Tijuana          97        834394  2018-05-20    Jesús  Vendida               729        1
    893          894 2016-03-27             Casa     Venta            Cancún         196        849464  2018-03-26    Jesús  Vendida               729        2
    721          722 2016-01-28          Oficina     Venta            Cancún         110        943800  2018-01-26    Jesús  Vendida               729        1
    1610        1611 2016-12-20            Local     Venta  Ciudad de México         281       2671748  2018-12-18   Carmen  Vendida               728        0
    1554        1555 2016-11-25  Estacionamiento  Alquiler            Cancún         295       2613405  2018-11-23   Carmen  Vendida               728        0
    1395        1396 2016-09-29       Industrial  Alquiler           Tijuana         121        490897  2018-09-27    María  Vendida               728        1
    1488        1489 2016-10-30  Estacionamiento  Alquiler  Ciudad de México         103        536733  2018-10-28    María  Vendida               728        1
    1326        1327 2016-08-31       Industrial     Venta           Tijuana         158       1473982  2018-08-29   Carmen  Vendida               728        2
    1606        1607 2016-12-17            Local     Venta           Tijuana         165       1393095  2018-12-15   Carmen  Vendida               728        2
    1337        1338 2016-09-07     Departamento  Alquiler            Cancún          99        938916  2018-09-04    Pedro  Vendida               727        1
    


```python
df['Fecha Venta'] = pd.to_datetime(df['Fecha Venta'])
df['Mes'] = df['Fecha Venta'].dt.to_period('M')  # Agrupar por mes
precios_promedio_mensuales = df.groupby('Mes')['Precio Venta'].mean().reset_index()
plt.figure(figsize=(12, 6))
plt.plot(precios_promedio_mensuales['Mes'].astype(str), precios_promedio_mensuales['Precio Venta'], marker='o')
plt.title('Evolución de los Precios de Venta de Inmuebles por Mes')
plt.xlabel('Mes')
plt.ylabel('Precio Promedio de Venta')
plt.xticks(rotation=45)  # Rotar las etiquetas del eje x para mejor legibilidad

plt.grid()
plt.tight_layout()  # Ajustar el diseño para que no se superpongan elementos
plt.show()
```


    
![png](output_36_0.png)
    

¿Cómo han evolucionado los precios de venta de los inmuebles en los últimos años? 
Para analizar la evolucion de los precios de las ventas se agrupa los promedios por meses,
esto permite visualizar la evolucion de los precios a lo largo del tiempo.


```python
df_ventas = df[df['Operación'] == 'Venta']
precios_promedio = df_ventas.groupby(['Ciudad', 'Tipo'])['Precio Venta'].mean().reset_index()
precios_promedio.rename(columns={'Precio Venta': 'PrecioPromedio'}, inplace=True)

# Formatear la columna 'PrecioPromedio'
precios_promedio['PrecioPromedio'] = precios_promedio['PrecioPromedio'].apply(lambda x: f"{x:,.2f}")

# Imprimir el DataFrame
print(precios_promedio)
```

                  Ciudad             Tipo PrecioPromedio
    0             Cancún             Casa   1,106,847.25
    1             Cancún     Departamento   1,032,479.60
    2             Cancún  Estacionamiento   1,229,344.48
    3             Cancún       Industrial   1,307,819.64
    4             Cancún            Local   1,278,478.36
    5             Cancún          Oficina   1,122,743.72
    6             Cancún          Terreno   1,026,276.72
    7   Ciudad de México             Casa   1,228,839.05
    8   Ciudad de México     Departamento   1,168,701.49
    9   Ciudad de México  Estacionamiento   1,149,324.59
    10  Ciudad de México       Industrial   1,283,821.59
    11  Ciudad de México            Local   1,300,523.68
    12  Ciudad de México          Oficina   1,207,923.62
    13  Ciudad de México          Terreno   1,309,398.07
    14         Monterrey             Casa   1,282,966.78
    15         Monterrey     Departamento   1,365,772.85
    16         Monterrey  Estacionamiento   1,180,556.28
    17         Monterrey       Industrial   1,006,846.96
    18         Monterrey            Local   1,248,935.69
    19         Monterrey          Oficina   1,305,124.52
    20         Monterrey          Terreno   1,350,894.64
    21           Tijuana             Casa   1,260,817.66
    22           Tijuana     Departamento   1,291,555.63
    23           Tijuana  Estacionamiento   1,207,011.12
    24           Tijuana       Industrial   1,177,282.88
    25           Tijuana            Local   1,211,232.09
    26           Tijuana          Oficina   1,265,099.91
    27           Tijuana          Terreno   1,200,037.53
    
